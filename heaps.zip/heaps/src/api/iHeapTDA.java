package api;

import imp.Elemento;

public interface iHeapTDA {
    int primero();
    void agregar(int x);
    void eliminar();
    boolean vacio();
    int cantidad();
}
